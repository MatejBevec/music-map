import os
import sys
import requests


def google_term(term):
    
    pass

def parse_desc(html):
    pass


if __name__ == "__main__":
    pass
    